#include <stdio.h>

int main(int argc, char const *argv[])
{
	printf("eggs\b&\tbacon\n");
	return 0;
}