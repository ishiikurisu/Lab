#include <stdlib.h>
#include <stdio.h>
#include <oa.h>

int main(int argc, char const *argv[])
{
	char* bitch = "";

	cat(bitch, "joe");
	cat(bitch, " frank");

	printf("%s\n", bitch);
	return 0;
}